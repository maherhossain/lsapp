<?php $__env->startSection('content'); ?>

    <h3>Create Post </h3>

    <?php echo Form::open(['action'=>['PostsController@update', $post->id], 'method'=>'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="foem-group">
            <?php echo e(Form::label("title", 'Title')); ?>

            <?php echo e(Form::text("title", $post->title, ['class'=> 'form-control', 'placeholder'=>'Title'])); ?>

        </div>

        <div class="form-group">
                <?php echo e(Form::label("body", 'Body')); ?>

                <?php echo e(Form::textarea("body", $post->body, ['id'=>'article-ckeditor', 'class'=> 'form-control mb-4', 'placeholder'=>'Content goes here'])); ?>

        </div>
        <div class="form-group">
                <?php echo e(Form::file('cover_image')); ?>

        </div>
        <?php echo e(Form::hidden('_method','PUT')); ?>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary btn-block '])); ?>

    



    <?php echo Form::close(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>