<?php $__env->startSection('content'); ?>
<h2>About</h2>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Molestiae ab fugiat fuga itaque eum placeat libero, magnam esse nemo illum vel aliquam excepturi corrupti numquam explicabo tenetur tempore laboriosam dolorum?</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>