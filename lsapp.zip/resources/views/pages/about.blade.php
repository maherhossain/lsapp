@extends('layouts.app')

@section('content')
<h2>About</h2>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Molestiae ab fugiat fuga itaque eum placeat libero, magnam esse nemo illum vel aliquam excepturi corrupti numquam explicabo tenetur tempore laboriosam dolorum?</p>

@endsection